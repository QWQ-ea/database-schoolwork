a="1"
b=str(a)
print(a)
print(b)