function encryptPassword(event) {
  event.preventDefault();

  var passwordInput = document.getElementById("password_input");
  var plaintext = passwordInput.value;


  const aesKey = CryptoJS.lib.WordArray.random(16); // 128位密钥
  const paddedData = CryptoJS.pad.Pkcs7.pad(CryptoJS.enc.Utf8.parse(plaintext));
  const encryptedData = CryptoJS.AES.encrypt(paddedData, aesKey, { mode: CryptoJS.mode.ECB });
  const encryptedString = encryptedData.toString();
  // 计算加密结果的MD5散列值
  var md5Hash = CryptoJS.MD5(encryptedData).toString();

  // 将加密结果和MD5散列值分别拼接，并将IV拼接在后面
  var encryptedWithIV = encrypted + " " + md5Hash ;

  document.getElementById("password_input").value = encryptedWithIV;

  // 提交表单
  document.getElementById("login_form").submit();
}

