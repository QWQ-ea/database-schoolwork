const args = process.argv.slice(2);
function decryptPassword(ciphertext, key) {
  var CryptoJS = require("./crypto-js");

  var decryptedData = CryptoJS.AES.decrypt(ciphertext, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  });
  var plaintext = decryptedData.toString(CryptoJS.enc.Utf8);
  var plaintext = JSON.stringify(plaintext)
    console.log(plaintext)
}
decryptPassword(args[0],args[1])

