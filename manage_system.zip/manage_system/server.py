import mysql.connector
from flask import Flask, request, render_template, session, redirect, url_for, request,abort
import hashlib
import subprocess

# 连接到 MySQL 数据库
conn = mysql.connector.connect(
    host="127.0.0.1",
    port=3306,
    user="root",
    password="12345",
    database="school1"
)
app = Flask(__name__)

@app.route('/',methods=['GET', 'POST'])
def login():
 if request.method == 'GET':
    return render_template('login.html',tip="")
 elif request.method == 'POST':
     id = request.form['id']
     pwd = request.form['password']
     # Split the string by space and assign the values
     encrypted_data, key ,md5_value= pwd.split(' ')
     print(encrypted_data)
     print(key)
     # 要执行的命令
     command = 'node D:\CS\DB\manage_system\static\js\decrypt.js'
     command=command+' '+encrypted_data+' '+key

     # 使用subprocess调用CMD执行命令
     decrypted_data = subprocess.run(command, shell=True, capture_output=True, text=True).stdout
     decrypted_data=decrypted_data.strip('\n').strip('"')

     # Calculate the MD5 hash of the encrypted data
     hash_md5 = hashlib.md5(encrypted_data.encode()).hexdigest()
     if hash_md5 == md5_value:
         pwd = decrypted_data
     else:
         return render_template('login.html', tip="传输过程出错，请重新输入！")
     cursor = conn.cursor()
     # 查询与ID匹配的记录及其密码字段
     query = "SELECT password FROM administrator_login WHERE id = %s"
     cursor.execute(query, (id,))
     result = cursor.fetchone()
     # 检查查询结果和密码是否匹配

     if result is not None and result[0] == pwd:
         return redirect(url_for('main_page'))
     else:
         return render_template('login.html', tip="id或password错误!")


@app.route('/main',methods=['GET', 'POST'])
def main_page():
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM department")
    departments = cursor.fetchall()
    return render_template('index.html', departments=departments)

@app.route('/personal_manage', methods=['GET', 'POST'])
def personal_manage():
    if request.method == 'GET':
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM administrator_login")
        administrator = cursor.fetchall()
        return render_template('personal_manage.html',administrator=administrator,tip="")
    elif request.method == 'POST':
        id=request.form['id']
        name=request.form['name']
        pwd1=request.form['password1']
        pwd2=request.form['password2']
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM administrator_login")
        administrator = cursor.fetchall()
        if id == administrator[0][0]:
          if name:
            cursor=conn.cursor()
            update_query="""UPDATE administrator_login SET name = %s WHERE id = %s"""
            cursor.execute(update_query,(name,id))
            conn.commit()
          if pwd1 and pwd2 and pwd1==pwd2:
            cursor = conn.cursor()
            update_query ="""UPDATE administrator_login SET password = %s WHERE id = %s"""
            cursor.execute(update_query,(pwd1,id))
            conn.commit()
          cursor=conn.cursor()
          cursor.execute("SELECT * FROM administrator_login")
          administrator = cursor.fetchall()
          return render_template('personal_manage.html', administrator=administrator, tip="保存成功！")
        else:
          return render_template('personal_manage.html', administrator=administrator, tip="id不存在！")

@app.route('/student_manage',methods=['GET', 'POST'])
def student_manage():
    if request.method == 'GET':
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM student")
        students = cursor.fetchall()
        return render_template('student_manage.html',students=students)
    elif request.method == 'POST':
        action =request.form['action']
        if action == 'delete':
            student_id = request.form['student_id']
            # 创建游标对象
            cursor = conn.cursor()
            # 执行删除语句
            sql = "DELETE FROM student WHERE student_id = %s"
            val = (student_id,)
            cursor.execute(sql, val)
            # 提交更改到数据库
            conn.commit()
            # 将 student_id 转换为字符串
            student_id = str(student_id)
            # 更新查询语句
            sql = "UPDATE student SET student_id = LPAD(CAST(student_id AS UNSIGNED) - 1, LENGTH(student_id), '0') WHERE CAST(student_id AS UNSIGNED) > %s"
            val = (student_id,)
            cursor.execute(sql, val)

            # Commit the changes to the database
            conn.commit()

            cursor.execute("SELECT * FROM student")
            students = cursor.fetchall()
            return render_template('student_manage.html', students=students,delete_tip="删除成功!", add_tip="", update_tip="")
        elif action == 'add':
            name = request.form['name']
            sex = request.form['sex']
            date_of_birth = request.form['date_of_birth']
            native_place = request.form['native_place']
            mobile_phone = request.form['mobile_phone']
            dept_id = request.form['dept_id']
            password = request.form['password']

            # Create cursor
            cursor = conn.cursor()
            select_sql = "SELECT MAX(CAST(student_id AS UNSIGNED)) FROM student"
            cursor.execute(select_sql)
            result = cursor.fetchone()
            max_student_id = str(int(result[0]) + 1)
            # Insert query
            sql = "INSERT INTO student (student_id, name, sex, date_of_birth, native_place, mobile_phone, dept_id, password) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
            val = (max_student_id, name, sex, date_of_birth, native_place, mobile_phone, dept_id, password)
            cursor.execute(sql, val)

            # Commit the changes to the database
            conn.commit()
            cursor.execute("SELECT * FROM student")
            students = cursor.fetchall()
            return render_template('student_manage.html', students=students, delete_tip="", add_tip="添加成功!",update_tip="")
        elif action == "update":
            student_id = request.form.get("student_id")
            name = request.form.get("name")
            sex = request.form.get("sex")
            date_of_birth = request.form.get("date_of_birth")
            native_place = request.form.get("native_place")
            mobile_phone = request.form.get("mobile_phone")
            dept_id = request.form.get("dept_id")
            password = request.form.get("password")

            # 构建更新语句和参数列表
            update_query = "UPDATE student SET "
            update_params = []

            if name:
                update_query += "name = %s, "
                update_params.append(name)
            if sex:
                update_query += "sex = %s, "
                update_params.append(sex)
            if date_of_birth:
                update_query += "date_of_birth = %s, "
                update_params.append(date_of_birth)
            if native_place:
                update_query += "native_place = %s, "
                update_params.append(native_place)
            if mobile_phone:
                update_query += "mobile_phone = %s, "
                update_params.append(mobile_phone)
            if dept_id:
                update_query += "dept_id = %s, "
                update_params.append(dept_id)
            if password:
                update_query += "password = %s, "
                update_params.append(password)

            # 移除更新语句末尾的逗号和空格
            update_query = update_query.rstrip(", ")

            # 添加WHERE条件
            update_query += " WHERE student_id = %s"
            update_params.append(student_id)

            # 执行数据库更新操作
            cursor = conn.cursor()
            cursor.execute(update_query, tuple(update_params))
            conn.commit()

            cursor.execute("SELECT * FROM student")
            students = cursor.fetchall()
            return render_template('student_manage.html', students=students, delete_tip="", add_tip="",update_tip="修改成功!")


@app.route('/teacher_manage',methods=['GET','POST'])
def teacher_manage():
    if request.method == 'GET':
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM teacher")
        teachers = cursor.fetchall()
        return render_template('teacher_manage.html',teachers=teachers)

@app.route('/course_manage',methods=['GET','POST'])
def course_manage():
     if request.method == 'GET':
         cursor = conn.cursor()
         cursor.execute("SELECT * FROM course")
         courses = cursor.fetchall()
         return render_template('course_manage.html', courses=courses)
     elif request.method == 'POST':
         action = request.form['action']
         if action == 'delete':
             course_id=request.form['course_id']
             cursor = conn.cursor()
             delete_query = "DELETE FROM course WHERE course_id = %s"
             # Execute the query
             cursor.execute(delete_query, (course_id,))
             # Commit the changes to the database
             conn.commit()

             cursor.execute("SELECT * FROM course")
             courses = cursor.fetchall()
             return render_template('course_manage.html', courses=courses)
         elif action == 'update':
             cursor = conn.cursor()

             # 获取表单提交的数据
             course_id = request.form['course_id']
             course_name = request.form.get('course_name')
             credit = request.form.get('credit')
             credit_hour = request.form.get('credit_hour')
             dept_id = request.form.get('dept_id')

             # 编写 SQL 查询语句
             sql = "UPDATE course SET "

             # 构建 SET 子句
             set_clauses = []
             if course_name:
                 set_clauses.append("course_name=%s")
             if credit:
                 set_clauses.append("credit=%s")
             if credit_hour:
                 set_clauses.append("credit_hours=%s")
             if dept_id:
                 set_clauses.append("dept_id=%s")

             sql += ", ".join(set_clauses)

             # 添加 WHERE 条件
             sql += " WHERE course_id=%s"

             # 执行更新操作
             params = []
             if course_name:
                 params.append(course_name)
             if credit:
                 params.append(credit)
             if credit_hour:
                 params.append(credit_hour)
             if dept_id:
                 params.append(dept_id)
             params.append(course_id)

             cursor.execute(sql, tuple(params))
             # 提交事务
             conn.commit()
             cursor.execute("SELECT * FROM course")
             courses = cursor.fetchall()
             return render_template('course_manage.html', courses=courses)
         elif action == 'add':
             course_name = request.form.get('course_name')
             credit = request.form.get('credit')
             credit_hours = request.form.get('credit_hours')
             dept_id = request.form.get('dept_id')

             # Find the maximum course_id for the given dept_id in the course table
             query = f"SELECT MAX(CAST(course_id AS UNSIGNED)) FROM course WHERE dept_id = '{dept_id}'"
             cursor = conn.cursor()
             cursor.execute(query)
             max_course_id = cursor.fetchone()[0]

             if max_course_id:
                 # Increment the course_id and format it with leading zeros
                 new_course_id = str(int(max_course_id) + 1).zfill(8)

             insert_query = f"INSERT INTO course (course_id, course_name, credit, credit_hours, dept_id) VALUES ('{new_course_id}', '{course_name}', '{credit}', '{credit_hours}', '{dept_id}')"
             cursor.execute(insert_query)
             # Commit the changes to the database
             conn.commit()
             cursor.execute("SELECT * FROM course")
             courses = cursor.fetchall()
             return render_template('course_manage.html', courses=courses)

@app.route('/class_manage', methods=['GET', 'POST'])
def class_manage():
    if request.method == 'GET':
        cursor = conn.cursor()
        # 查询class表并根据staff_id分组
        query = "SELECT staff_id, semester, class_weekday, course_start, course_end, course_id FROM class ORDER BY staff_id"
        cursor.execute(query)
        results = cursor.fetchall()
        # 获取教师列表
        teachers = set([row[0] for row in results])
        tables_data = []  # List to store table data for each teacher

        for teacher in teachers:
            teacher_results = [row for row in results if row[0] == teacher]

            table_data = []
            current_staff_id = None

            # 添加教师的staff_id作为标题
            table_data.append(f"<tr><th colspan='6'>2012-2013秋季学期 staff_id:{teacher}</th></tr>")

            # 添加星期几作为表格第一行
            table_data.append("<tr>")
            table_data.append("<th></th>")  # 空单元格用于间距
            weekdays = ["星期一", "星期二", "星期三", "星期四", "星期五"]
            for weekday in weekdays:
                table_data.append(f"<th>{weekday}</th>")
            table_data.append("</tr>")

            for i in range(1, 13):
                table_data.append("<tr>")
                table_data.append(f"<td>{i}</td>")  # 表格单元格显示数字

                for weekday in weekdays:
                    course_id = "-"
                    for row in teacher_results:
                        staff_id, semester, class_weekday, course_start, course_end, id = row
                        if (
                                class_weekday == weekday
                                and int(course_start) <= i <= int(course_end)
                        ):
                            course_id = id
                            break

                    table_data.append(f"<td>{course_id}</td>")

                table_data.append("</tr>")

            tables_data.append("".join(table_data))

        return render_template("class_manage.html", tables_data=tables_data,message="")

    elif request.method == 'POST':
            cursor = conn.cursor()
            try:
              course_id = request.form.get('course_id')
              staff_id = request.form.get('staff_id')
              class_weekday = request.form.get('class_weekday')
              course_start = request.form.get('course_start')
              course_end = request.form.get('course_end')

             # 准备要插入的数据
              data = {
                 'course_id': course_id,
                 'staff_id': staff_id,
                 'class_weekday': class_weekday,
                 'course_start': course_start,
                 'course_end': course_end,
                     }


              cursor.execute(
                "INSERT INTO class(course_id, staff_id, class_weekday, course_start, course_end) VALUES (%s, %s, %s, %s, %s)",
                (
                    data['course_id'], data['staff_id'], data['class_weekday'], data['course_start'], data['course_end']
                ))


              conn.commit()
              message_text ="排课成功!"
            except mysql.connector.Error as e:
              # 获取触发器返回的MESSAGE_TEXT消息
              message_text = str(e)

            query = "SELECT staff_id, semester, class_weekday, course_start, course_end, course_id FROM class ORDER BY staff_id"
            cursor.execute(query)
            results = cursor.fetchall()
            # 获取教师列表
            teachers = set([row[0] for row in results])
            tables_data = []  # List to store table data for each teacher

            for teacher in teachers:
                teacher_results = [row for row in results if row[0] == teacher]

                table_data = []
                current_staff_id = None

                # 添加教师的staff_id作为标题
                table_data.append(f"<tr><th colspan='6'>2012-2013秋季学期 staff_id:{teacher}</th></tr>")

                # 添加星期几作为表格第一行
                table_data.append("<tr>")
                table_data.append("<th></th>")  # 空单元格用于间距
                weekdays = ["星期一", "星期二", "星期三", "星期四", "星期五"]
                for weekday in weekdays:
                    table_data.append(f"<th>{weekday}</th>")
                table_data.append("</tr>")

                for i in range(1, 13):
                    table_data.append("<tr>")
                    table_data.append(f"<td>{i}</td>")  # 表格单元格显示数字

                    for weekday in weekdays:
                        course_id = "-"
                        for row in teacher_results:
                            staff_id, semester, class_weekday, course_start, course_end, id = row
                            if (
                                    class_weekday == weekday
                                    and int(course_start) <= i <= int(course_end)
                            ):
                                course_id = id
                                break

                        table_data.append(f"<td>{course_id}</td>")

                    table_data.append("</tr>")

                tables_data.append("".join(table_data))

            return render_template("class_manage.html", tables_data=tables_data, message=message_text)



if __name__ == '__main__':
    app.run(debug=True)
